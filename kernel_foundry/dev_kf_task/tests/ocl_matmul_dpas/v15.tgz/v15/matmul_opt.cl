/*
[USER_INSTRUCTIONS_START]
- Current kernel achieves 0.948ms = 23% XMX utilization on B580 (96 TFLOPS peak).
    Architecture: 64 WIs (4 SGs), A in SLM (2.2KB), B from global/L2, TILE 32x64x32.
    DO NOT change the fundamental architecture (this was proven best).
    DO NOT add B to SLM (causes regression).
    DO NOT increase WG beyond 64 WIs (causes regression).
    DO NOT use 32×256 tile (proven inferior to 32×64)
    DO NOT use K-step smaller than 32
    Micro-optimizations to try:
        - Combine double-buffering with K-loop 2x unroll
        - More aggressive B prefetch strategies
        - Explore different SLM strides to avoid bank conflicts
        - Try async copy (intel_sub_group_block_read for A loads)
        - Use intel_sub_group_block_read_us for SLM A reads (vectorized)
        - Merge paired B scalar reads into vload2 or block reads
        - Remove K-remainder path (K=2048 divides evenly by 32)
        - Try TILE_M=48 or 64 (more A rows per WG, same B columns)
        - Unroll K-loop 2x (reduce loop overhead for 64 tiles)
        - Add __builtin_prefetch or intel_sub_group_block_prefetch for next B tile
    Hardware: B580 = 20 Xe2 cores, 96 TFLOPS FP16 XMX, 456 GB/s, 32MB L2, 64 KB SLM per tile.
    DPAS: intel_sub_group_f16_f16_matrix_mad_k16(short8 a, int8 b, float8 acc)

    ================================================================================
    OpenCL GEMM Kernel Optimization Tips
    (Based on oneDNN gemmstone f16 uncompressed-weight path)
    ================================================================================

    The tips below target f16 activation × f16 weight → f16/f32 output GEMM kernels
    on Intel Xe-HPG / Xe-HPC / Xe2 / Xe3 GPUs.
    Each item reflects strategies actually used in oneDNN and can be used directly
    as practical references for OpenCL kernel optimization.

    [Compute Instructions]

    1. Use DPAS (systolic) for f16×f16→f32 outer-product accumulation
    - Each DPAS performs repcount×depth MAC operations (typical: repcount=8, depth=8)
    - exec_size: XeHP/HPG=8, XeHPC/Xe2/Xe3=16
    - This keeps the core compute path compute-bound instead of ALU-issue-bound

    2. Use f32 accumulators
    - Even if A/B are f16, keep C accumulators in f32 for better accuracy
    - Do f32→f16 downcast only once at the end of the k-loop
    - Benefit: less intermediate rounding error; f32 atomic add is also more portable than f16

    3. If hardware has fused EU (XeHP/HPG), consider DPASW
    - DPASW lets one fused-EU pair share operand B, reducing B register pressure
    - Not applicable on Xe-HPC and newer (no fused EU)

    [Data Layout / Register Tile]

    4. Choose an appropriate register tile: unrollM × unrollN
    - Typical values: 32×32 (XeHP), 32×48 (XeHPC), adjusted by GRF budget
    - Larger tile → higher compute/memory ratio, but also higher GRF pressure
    - You must fit A tile + B tile + C accumulators + prefetch buffers simultaneously

    5. Crosspack = 2 for f16
    - DPAS expects f16 operands packed in 32-bit lanes, i.e. two consecutive k elements
    - If global-memory layout does not match, repacking is required
    - Prefer producing crosspack-friendly layout directly at load time (e.g., Block2D-VNNI)

    6. A tile: unrollM × ka_load; B tile: kb_load × unrollN
    - ka_load / kb_load indicate how many K iterations are loaded per memory transaction
    - Larger ka_load can improve load coalescing and reduce address overhead
    - But overly large ka_load increases GRF usage (especially with multi-copy buffers)

    [Memory Access]

    7. Prefer 2D Block Load (intel_subgroup_block_read_*)
    - XeHPC+ supports 2D Block Load with built-in VNNI reorder:
        loading B can directly produce crosspack=2 format, avoiding repack instructions
    - Transpose mode is also supported: row-major B may not need explicit transpose
    - Requires 16-byte aligned base address; otherwise may fall back to scattered access

    8. Use Block Load (1D / 2D) for matrix A when possible
    - Column-major A (contiguous in M) naturally fits Block Load
    - For row-major A, consider Block2D-Transpose or cooperative copy into SLM first

    9. Set LSC cache hints carefully
    - Load A/B: L1-cached + L3-cached (default {cc})
    - Store C: L1-uncached + L3-write-back ({uc,wb}) to avoid polluting L1
    - Prefetch: L1-streaming or L1-invalidate-after-read ({sc} / {ic})
    - Xe3p provides independent L2 hints for finer 3-level cache control

    10. Guarantee 16-byte alignment
        - 2D Block Load requires 16B-aligned surface base
        - If leading dimensions are not multiples of 16B, block-2D may be unavailable
        - Practical approach: pad LDA/LDB to multiples of 16 during buffer allocation

    [Prefetch Strategy]

    11. Use a three-level prefetch scheme
        - L1/L2 prefetch: distance = prefetchA/B × unrollK (typically 3~6 k-iterations)
        - L3 prefetch (Xe2+): longer-distance dedicated prefetch messages, cooperatively distributed
        - TLB warmup: issue dummy loads for first A/B chunks before k-loop to prefill TLB

    12. Tune prefetch distance
        - Too short → data arrives late, causing compute stalls
        - Too long → prefetched lines may be evicted too early
        - Rule of thumb: global→L2 about 3~4 iterations; global→L3 about 6~8 iterations

    13. Use cooperative prefetch
        - Let all WG threads share prefetch work (instead of each thread prefetching only its own slice)
        - Reduces redundant prefetch and improves bandwidth utilization
        - Implementation idea: each thread prefetches a different K-slice subset of A/B

    [SLM (Shared Local Memory) Usage]

    14. Use SLM double/triple buffering
        - While one buffer is consumed by DPAS, another is filled from global memory
        - Double buffer = ~1 barrier per iteration; triple buffer can hide more barrier cost
        - SLM buffer size = unrollM × unrollK_SLM × sizeof(f16) (per A/B)

    15. Cooperative SLM copy (global → SLM)
        - WG threads collaboratively move A/B from global memory into SLM
        - Split modes: by K, by M/N, or linear split
        - K-split is common: each thread handles a contiguous K segment for best coalescing

    16. SLM → Register load
        - Use block_read from SLM; data can already be in crosspack layout
        - Watch SLM bank conflicts: avoid adjacent threads targeting the same bank
        - Add SLM leading-dimension padding (+1 or +4 elements) to mitigate conflicts

    17. WAR fence for SLM reuse
        - XeHPG+ requires fence before reusing/swapping SLM buffers (slmFenceWARWA)
        - Prevents later writes from overwriting in-flight reads

    [K-loop Pipeline]

    18. Load pipelining (A_copies / B_copies)
        - Multiple load buffers: DPAS consumes buffer i while loading buffer i+1
        - Typical 2-deep: one register set computing, one register set loading
        - 4-deep can hide very high global-memory latency in extreme cases

    19. Interleave load/compute/prefetch instructions
        - Exploit GPU out-of-order scheduling by inserting load/prefetch between DPAS instructions
        - Keep load units and systolic units busy in parallel
        - Key fact: DPAS is long-latency (~20 cycles on Xe2), leaving room for memory ops

    20. Unroll the K-loop (unrollK)
        - Reduces loop overhead and address-increment instructions
        - Typical unrollK = ka_load = 16 or 32 for f16
        - Too large can bloat code size and hurt i-cache behavior

    [WG Scheduling / Parallelization]

    21. Choose workgroup shape carefully
        - WG has wg[M] × wg[N] threads, each computing an unrollM × unrollN C tile
        - Total WG tile = wg[M]*unrollM × wg[N]*unrollN
        - Try to fit WG tile working set into L2 resident set (A panel + B panel)

    22. Walk order: Boustrophedon / Nested-Linear
        - Default row-major dispatch often has weak L2 reuse
        - Boustrophedon (snake pattern): neighboring WGs share A panel, improving L2 hit rate
        - Nested-Linear: iterate inner panel first, then move to next panel
        - Especially effective for decode-like GEMM (large N, small M)

    23. Persistent threads
        - A single WG processes multiple tiles (via global atomic tile counter)
        - Reduces repeated launch/prolog overhead
        - Residual hot data in L1/L2 from previous tile can be reused directly

    24. Stream-K (split K across multiple WGs)
        - If M×N work is insufficient to fill GPU, split K across WGs
        - Each WG computes partial K and merges with atomic add
        - Useful for decode stage (M=1~8, large N, large K)

    25. Named barriers (per row/col)
        - Synchronize only the thread subset that actually interacts
        - Example: SLM A sync only across M-direction threads, B only across N-direction threads
        - Reduces unnecessary waiting

    [C Matrix Writeback]

    26. Delayed f32→f16 cast + vectorized store
        - Convert f32→f16 once after accumulation, then use block_write to store
        - Alternative: use block_write_us (unsigned short) for f16 output
        - Merge tiny scattered writes; keep C stores block-aligned whenever possible

    27. Atomic C update for K-parallel modes
        - When K is split across WGs, C requires atomic accumulation
        - f32 atomic add: available on XeHP+ (stateless A64 model)
        - f16 atomic add: native only on Xe3p; otherwise use CAS loop or f32 temporary path

    28. 2D Block Store for C (XeHPC+)
        - Block2D can also write C and reduce explicit row/col-tail mask handling
        - block2DCRemainder mode can still auto-fallback to scattered for tail tiles

    [Tail / Remainder Handling]

    29. Dual-mask system (rowMask + colMask)
        - One load/store instruction handles both row and column tails
        - Reduces branches and special-case code in tail processing
        - block-2D also supports descriptor-based remainder handling

    30. Descriptor-based remainder
        - Handle boundaries by changing block_2d width/height descriptor fields
        - Zero extra ALU overhead (compared with mask-register predication)
        - Applicable only to block-2D access types

    [Register Allocation]

    31. Bank-aware GRF allocation
        - Avoid placing A/B operands and accumulators in the same GRF bank (bank conflict)
        - Practical rule: place A in even bank, B in odd bank, C accumulators flexible
        - In OpenCL: use register-allocation attributes (if available) or manual register-pressure shaping

    32. Choosing GRF count: 128 vs 256
        - 256 GRF → larger tiles and higher compute density, but occupancy drops to ~4 threads/EU
        - 128 GRF → smaller tiles, but ~8 threads/EU can hide latency better
        - For bandwidth-bound cases (small K), prefer 128; for compute-bound cases (large K), prefer 256

    [Misc]

    33. TLB warmup for large matrices
        - Issue one dummy load per A/B page before entering k-loop
        - Prefills TLB and avoids page-walk stalls in main loop
        - Usually helps once A/B footprint exceeds ~256KB

    34. Boustrophedon internal FMA ordering (fmaBoustrophedon)
        - Arrange DPAS/FMA order in snake pattern: one pass forward, next pass reverse
        - Improves register locality (neighboring DPAS reuses source registers)
        - Reduces RAW stalls

    35. cLoadAhead (C preload)
        - If beta ≠ 0, preload current C tile in advance
        - Overlap C-load latency with tail part of k-loop DPAS
        - Then directly compute fma(alpha, acc, beta, C_old) and write back

    36. Avoid unnecessary repack
        - If A/B are already in DPAS-friendly memory layout (packed, crosspack=2):
        load directly to GRF via block-load without extra SLM copy + repack
        - Quick check: isPacked(A.layout) && alignment >= 16

    37. Kernel catalog / auto-tuning mindset
        - Use different tile/strategy combinations for different (M,N,K) ranges
        - Small M (decode): smaller unrollM, larger unrollN, possibly no-SLM, Stream-K
        - Large M (prefill): larger unrollM, SLM double buffer, Boustrophedon walk

- Provide explicit launch metadata (GWS/LWS/subgroup hints) in kernel comments.
- Please update task.py to align with kernel's GWS/LWS and other assumptions if you make significant changes to the kernel structure.
[USER_INSTRUCTIONS_END]
*/


// __kernel void matmul(
//     __global const half* restrict A,
//     __global const half* restrict B,
//     __global half* restrict C,
//     const int M,
//     const int K,
//     const int N)
// {
// }


// [EVOLVE_START]
// v28 (FINAL): v24 base (K-unroll x2 + 2D wide A read) + WG swizzle
// Result: K=2560 ~65%, K=4096 ~60% of 96 TFLOPS f16 roofline on Arc B580
// Goal: > 60% efficiency

#pragma OPENCL EXTENSION cl_khr_fp16 : enable
#pragma OPENCL EXTENSION cl_intel_subgroups : enable
#pragma OPENCL EXTENSION cl_intel_subgroup_2d_block_io : enable

#define TILE_M 32
#define TILE_N 32
#define WG_M 4
#define WG_N 8
#define SG_SIZE 16
#define WG_TILE_M (WG_M * TILE_M)
#define WG_TILE_N (WG_N * TILE_N)
#define NUM_SG (WG_M * WG_N)
#define WG_SIZE (NUM_SG * SG_SIZE)

// Swizzle parameter: groups SWIZZLE consecutive WGs along M dim
// so they share B columns (better L3 reuse on B)
#define SWIZZLE 2

__attribute__((intel_reqd_sub_group_size(SG_SIZE)))
__attribute__((reqd_work_group_size(WG_SIZE, 1, 1)))
__kernel void matmul(
    __global const half* restrict A,
    __global const half* restrict B,
    __global half* restrict C,
    int M, int N, int K)
{
    const int sg_id  = get_sub_group_id();
    const int sg_row = sg_id / WG_N;
    const int sg_col = sg_id % WG_N;

    // L3-aware WG swizzle: walk M dim in blocks of SWIZZLE before incrementing N
    const int grid_m = get_num_groups(0);
    const int grid_n = get_num_groups(1);
    const int gid0 = get_group_id(0);
    const int gid1 = get_group_id(1);
    const int linear = gid1 * grid_m + gid0;
    const int block_size = SWIZZLE * grid_n;
    const int block_id = linear / block_size;
    const int block_off = linear % block_size;
    const int rem_m = grid_m - block_id * SWIZZLE;
    const int cur_swizzle = (rem_m < SWIZZLE) ? rem_m : SWIZZLE;
    const int gn = block_off / cur_swizzle;
    const int gm = block_id * SWIZZLE + (block_off % cur_swizzle);

    const int tile_m = gm * WG_TILE_M + sg_row * TILE_M;
    const int tile_n = gn * WG_TILE_N + sg_col * TILE_N;

    float8 acc00 = 0, acc10 = 0, acc20 = 0, acc30 = 0;
    float8 acc01 = 0, acc11 = 0, acc21 = 0, acc31 = 0;

    const int A_wb = K * 2, A_pb = K * 2;
    const int B_wb = N * 2, B_pb = N * 2;

    for (int k0 = 0; k0 < K; k0 += 32) {
        ushort a_data[64];
        intel_sub_group_2d_block_read_16b_32r16x2c(
            (__global void*)A, A_wb, M, A_pb, (int2)(k0, tile_m), a_data);

        uint b0_data[16], b1_data[16];
        intel_sub_group_2d_block_read_transform_16b_16r16x2c(
            (__global void*)B, B_wb, K, B_pb, (int2)(tile_n, k0),      b0_data);
        intel_sub_group_2d_block_read_transform_16b_16r16x2c(
            (__global void*)B, B_wb, K, B_pb, (int2)(tile_n, k0 + 16), b1_data);

        {
            int8 b0 = as_int8(*(__private uint8*)&b0_data[0]);
            int8 b1 = as_int8(*(__private uint8*)&b0_data[8]);
            short8 a0 = as_short8(*(__private ushort8*)&a_data[0]);
            short8 a1 = as_short8(*(__private ushort8*)&a_data[8]);
            short8 a2 = as_short8(*(__private ushort8*)&a_data[16]);
            short8 a3 = as_short8(*(__private ushort8*)&a_data[24]);
            acc00 = intel_sub_group_f16_f16_matrix_mad_k16(a0, b0, acc00);
            acc01 = intel_sub_group_f16_f16_matrix_mad_k16(a0, b1, acc01);
            acc10 = intel_sub_group_f16_f16_matrix_mad_k16(a1, b0, acc10);
            acc11 = intel_sub_group_f16_f16_matrix_mad_k16(a1, b1, acc11);
            acc20 = intel_sub_group_f16_f16_matrix_mad_k16(a2, b0, acc20);
            acc21 = intel_sub_group_f16_f16_matrix_mad_k16(a2, b1, acc21);
            acc30 = intel_sub_group_f16_f16_matrix_mad_k16(a3, b0, acc30);
            acc31 = intel_sub_group_f16_f16_matrix_mad_k16(a3, b1, acc31);
        }
        {
            int8 b0 = as_int8(*(__private uint8*)&b1_data[0]);
            int8 b1 = as_int8(*(__private uint8*)&b1_data[8]);
            short8 a0 = as_short8(*(__private ushort8*)&a_data[32]);
            short8 a1 = as_short8(*(__private ushort8*)&a_data[40]);
            short8 a2 = as_short8(*(__private ushort8*)&a_data[48]);
            short8 a3 = as_short8(*(__private ushort8*)&a_data[56]);
            acc00 = intel_sub_group_f16_f16_matrix_mad_k16(a0, b0, acc00);
            acc01 = intel_sub_group_f16_f16_matrix_mad_k16(a0, b1, acc01);
            acc10 = intel_sub_group_f16_f16_matrix_mad_k16(a1, b0, acc10);
            acc11 = intel_sub_group_f16_f16_matrix_mad_k16(a1, b1, acc11);
            acc20 = intel_sub_group_f16_f16_matrix_mad_k16(a2, b0, acc20);
            acc21 = intel_sub_group_f16_f16_matrix_mad_k16(a2, b1, acc21);
            acc30 = intel_sub_group_f16_f16_matrix_mad_k16(a3, b0, acc30);
            acc31 = intel_sub_group_f16_f16_matrix_mad_k16(a3, b1, acc31);
        }
    }

    #define STORE_BLOCK(acc, row_off, col_off) { \
        ushort c_data[8]; \
        c_data[0] = as_ushort((half)acc.s0); c_data[1] = as_ushort((half)acc.s1); \
        c_data[2] = as_ushort((half)acc.s2); c_data[3] = as_ushort((half)acc.s3); \
        c_data[4] = as_ushort((half)acc.s4); c_data[5] = as_ushort((half)acc.s5); \
        c_data[6] = as_ushort((half)acc.s6); c_data[7] = as_ushort((half)acc.s7); \
        intel_sub_group_2d_block_write_16b_8r16x1c( \
            (__global void*)C, N * 2, M, N * 2, \
            (int2)(tile_n + col_off, tile_m + row_off), c_data); \
    }
    STORE_BLOCK(acc00, 0, 0);  STORE_BLOCK(acc10, 8, 0);
    STORE_BLOCK(acc20, 16, 0); STORE_BLOCK(acc30, 24, 0);
    STORE_BLOCK(acc01, 0, 16); STORE_BLOCK(acc11, 8, 16);
    STORE_BLOCK(acc21, 16, 16); STORE_BLOCK(acc31, 24, 16);
    #undef STORE_BLOCK
}
// [EVOLVE_END]



// #pragma OPENCL EXTENSION cl_intel_subgroups : enable
// #pragma OPENCL EXTENSION cl_intel_subgroup_matrix_multiply_accumulate : enable
// #pragma OPENCL EXTENSION cl_khr_fp16 : enable
// #pragma OPENCL EXTENSION cl_intel_subgroups_short : enable

// // WG tile: 32 rows x 64 cols, K-step: 32
// // 4 subgroups x 16 WIs = 64 WIs per WG
// // Each subgroup: 4 vertical 8x16 DPAS tiles = 32 rows x 16 cols
// // A cached in SLM (double-buffered: 2x 2KB = 4KB), B loaded directly from global/L2
// // K=2048 divides evenly by 32, no remainder path needed.
// // Double-buffering: load next A tile while computing on current tile.
// // GWS = (ceil(N/64)*64, ceil(M/32))  LWS = (64, 1)

// #define TILE_M 32
// #define TILE_N 64
// #define TILE_K 32
// #define SLM_TILE (TILE_M * TILE_K)

// __attribute__((intel_reqd_sub_group_size(16)))
// __attribute__((reqd_work_group_size(64, 1, 1)))
// __kernel void matmul_v14(
//     __global const half* restrict A,
//     __global const half* restrict B,
//     __global half* restrict C,
//     const int M,
//     const int K,
//     const int N)
// {
//     const int sg_id = get_sub_group_id();
//     const int sg_lid = get_sub_group_local_id();
//     const int lid = get_local_id(0);

//     const int n_base = get_group_id(0) * TILE_N;
//     const int col_base = n_base + sg_id * 16;
//     const int row_base = get_group_id(1) * TILE_M;

//     // Double-buffered SLM for A
//     __local ushort slm_A[2 * SLM_TILE];

//     if (row_base >= M || n_base >= N)
//         return;

//     float8 acc0 = 0.0f;
//     float8 acc1 = 0.0f;
//     float8 acc2 = 0.0f;
//     float8 acc3 = 0.0f;

//     const int col_idx = col_base + sg_lid;
//     const bool col_valid = col_idx < N;
//     const bool row_tile_valid = (row_base + TILE_M <= M);
//     const int num_k_tiles = K >> 5;

//     const int b_col = col_valid ? col_idx : (N - 1);

//     __global const ushort* A_us = (__global const ushort*)A;
//     __global const ushort* B_us = (__global const ushort*)B;

//     const int a_row_base_K = row_base * K;
//     const int N2 = N << 1;

//     // Precompute per-WI A-load info
//     int a_local_off[16];
//     int a_r[16];
//     int a_c[16];
//     #pragma unroll
//     for (int i = 0; i < 16; i++) {
//         int elem_id = lid + i * 64;
//         a_r[i] = elem_id >> 5;
//         a_c[i] = elem_id & 31;
//         a_local_off[i] = elem_id;
//     }

//     // Load first A tile into buffer 0
//     {
//         __local ushort* dst = slm_A;
//         if (row_tile_valid) {
//             __global const ushort* A_tile = A_us + a_row_base_K;
//             #pragma unroll
//             for (int i = 0; i < 16; i++)
//                 dst[a_local_off[i]] = A_tile[a_r[i] * K + a_c[i]];
//         } else {
//             #pragma unroll
//             for (int i = 0; i < 16; i++) {
//                 int gr = row_base + a_r[i];
//                 dst[a_local_off[i]] = (gr < M) ? A_us[gr * K + a_c[i]] : (ushort)0;
//             }
//         }
//     }
//     barrier(CLK_LOCAL_MEM_FENCE);

//     int cur_buf = 0;

//     for (int kt = 0; kt < num_k_tiles; kt++) {
//         const int k = kt * TILE_K;
//         const int next_kt = kt + 1;
//         const bool has_next = (next_kt < num_k_tiles);

//         __local const ushort* cur_slm = slm_A + cur_buf * SLM_TILE;

//         // ---- COMPUTE k16 step 0 ----
//         {
//             short8 a0, a1, a2, a3;

//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 ((ushort*)&a0)[r] = intel_sub_group_block_read_us(cur_slm + r * TILE_K);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 ((ushort*)&a1)[r] = intel_sub_group_block_read_us(cur_slm + (8 + r) * TILE_K);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 ((ushort*)&a2)[r] = intel_sub_group_block_read_us(cur_slm + (16 + r) * TILE_K);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 ((ushort*)&a3)[r] = intel_sub_group_block_read_us(cur_slm + (24 + r) * TILE_K);

//             int b_off = k * N + b_col;
//             int8 b_val;
//             #pragma unroll
//             for (int p = 0; p < 8; p++) {
//                 ushort s0 = B_us[b_off];
//                 ushort s1 = B_us[b_off + N];
//                 ((int*)&b_val)[p] = as_int((ushort2)(s0, s1));
//                 b_off += N2;
//             }

//             acc0 = intel_sub_group_f16_f16_matrix_mad_k16(a0, b_val, acc0);
//             acc1 = intel_sub_group_f16_f16_matrix_mad_k16(a1, b_val, acc1);
//             acc2 = intel_sub_group_f16_f16_matrix_mad_k16(a2, b_val, acc2);
//             acc3 = intel_sub_group_f16_f16_matrix_mad_k16(a3, b_val, acc3);
//         }

//         // ---- COMPUTE k16 step 1 ----
//         {
//             short8 a0, a1, a2, a3;
//             __local const ushort* slm_base = cur_slm + 16;

//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 ((ushort*)&a0)[r] = intel_sub_group_block_read_us(slm_base + r * TILE_K);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 ((ushort*)&a1)[r] = intel_sub_group_block_read_us(slm_base + (8 + r) * TILE_K);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 ((ushort*)&a2)[r] = intel_sub_group_block_read_us(slm_base + (16 + r) * TILE_K);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 ((ushort*)&a3)[r] = intel_sub_group_block_read_us(slm_base + (24 + r) * TILE_K);

//             int b_off = (k + 16) * N + b_col;
//             int8 b_val;
//             #pragma unroll
//             for (int p = 0; p < 8; p++) {
//                 ushort s0 = B_us[b_off];
//                 ushort s1 = B_us[b_off + N];
//                 ((int*)&b_val)[p] = as_int((ushort2)(s0, s1));
//                 b_off += N2;
//             }

//             acc0 = intel_sub_group_f16_f16_matrix_mad_k16(a0, b_val, acc0);
//             acc1 = intel_sub_group_f16_f16_matrix_mad_k16(a1, b_val, acc1);
//             acc2 = intel_sub_group_f16_f16_matrix_mad_k16(a2, b_val, acc2);
//             acc3 = intel_sub_group_f16_f16_matrix_mad_k16(a3, b_val, acc3);
//         }

//         // ---- LOAD next A tile ----
//         if (has_next) {
//             __local ushort* next_slm = slm_A + (1 - cur_buf) * SLM_TILE;
//             barrier(CLK_LOCAL_MEM_FENCE);

//             const int next_k = next_kt * TILE_K;
//             if (row_tile_valid) {
//                 __global const ushort* A_tile = A_us + a_row_base_K + next_k;
//                 #pragma unroll
//                 for (int i = 0; i < 16; i++)
//                     next_slm[a_local_off[i]] = A_tile[a_r[i] * K + a_c[i]];
//             } else {
//                 #pragma unroll
//                 for (int i = 0; i < 16; i++) {
//                     int gr = row_base + a_r[i];
//                     next_slm[a_local_off[i]] = (gr < M) ? A_us[gr * K + next_k + a_c[i]] : (ushort)0;
//                 }
//             }

//             barrier(CLK_LOCAL_MEM_FENCE);
//             cur_buf = 1 - cur_buf;
//         }
//     }

//     // Store results
//     if (col_valid) {
//         __global half* C_col = C + col_idx;
//         if (row_tile_valid) {
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 C_col[(row_base + r) * N] = convert_half(((float*)&acc0)[r]);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 C_col[(row_base + 8 + r) * N] = convert_half(((float*)&acc1)[r]);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 C_col[(row_base + 16 + r) * N] = convert_half(((float*)&acc2)[r]);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 C_col[(row_base + 24 + r) * N] = convert_half(((float*)&acc3)[r]);
//         } else {
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 if (row_base + r < M) C_col[(row_base + r) * N] = convert_half(((float*)&acc0)[r]);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 if (row_base + 8 + r < M) C_col[(row_base + 8 + r) * N] = convert_half(((float*)&acc1)[r]);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 if (row_base + 16 + r < M) C_col[(row_base + 16 + r) * N] = convert_half(((float*)&acc2)[r]);
//             #pragma unroll
//             for (int r = 0; r < 8; r++)
//                 if (row_base + 24 + r < M) C_col[(row_base + 24 + r) * N] = convert_half(((float*)&acc3)[r]);
//         }
//     }
// }

